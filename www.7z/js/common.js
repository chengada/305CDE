$( document ).bind( "mobileinit", function() {

    $.mobile.allowCrossDomainPages = true;
});

var hosturl = "http://www.adacheng.me.ht/";

function checkUser(){
    if (localStorage.userid != undefined) { 
        }
        else{
            window.location.href="login.html";
        }
}

function logout() {
        localStorage.clear();
}

function tempAlert(msg,duration)
{
	var el = document.createElement("div");
	el.setAttribute("style","position:absolute;top:25%;left:20%;background-color:white;padding:4vw;border-radius: 3vw;box-shadow: 0 2vw 5vw #ffa3a3;");
	el.setAttribute("class","ui-corner-all");
	el.innerHTML = msg + '<br/>';
	setTimeout(function(){
	el.parentNode.removeChild(el);
	},duration);
	document.body.appendChild(el);
}

