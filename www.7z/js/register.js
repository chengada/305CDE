$(document).on('pageinit',(function() {
		$("register-form").validate({
			rules: {
				fname: "required",
				lname : "required",
				username: {
					required : true,
					minlength : 5
				},
				password : {
					required : true,
					minlength : 5
				},
				confirmpassword : {
					required : true,
					equalTo : "#password"
				},
				email: {
					required: true,
					email: true
				}
			},
			messages: {
				fname: "Please enter your First Name",
				lname : "Please enter your Last Name",
				email: "Please enter valid email @",
				username : {
					required : "Please enter a Username",
					minlength : "Your user name must consist of at least 5 characters",
				},
				password : {
					required : "Please provde a password",
					minlength : "Your password must be at least 5 characters long"
				},
				confirmpassword : {
					required : "Please provide a password",
					equalTo : "Please enter the same password as above"
				}
			}

		});
});